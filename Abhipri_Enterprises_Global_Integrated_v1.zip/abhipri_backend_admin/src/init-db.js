require("dotenv").config();
const bcrypt = require("bcryptjs");
const db = require("./db");

const email = (process.env.ADMIN_EMAIL || "admin@abhiprienterprises.in").trim().toLowerCase();
const password = process.env.ADMIN_PASSWORD || "ChangeThisAdminPassword123!";
const name = process.env.ADMIN_NAME || "Abhipri Administrator";

if (password.length < 12) {
  console.error("ADMIN_PASSWORD must be at least 12 characters.");
  process.exit(1);
}
const existing = db.prepare("SELECT id FROM users WHERE email = ?").get(email);
if (existing) {
  console.log(`Admin account already exists (user id ${existing.id}). No password changed.`);
} else {
  const hash = bcrypt.hashSync(password, 12);
  const result = db.prepare("INSERT INTO users (name,email,password_hash,role) VALUES (?,?,?,'admin')").run(name,email,hash);
  console.log(`Created first admin account (user id ${result.lastInsertRowid}).`);
}
console.log("Database schema is ready.");
