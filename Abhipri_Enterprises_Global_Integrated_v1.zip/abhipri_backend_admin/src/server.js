require("dotenv").config();
const express = require("express");
const path = require("node:path");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const helmet = require("helmet");
const cors = require("cors");
const rateLimit = require("express-rate-limit");
const db = require("./db");

const app = express();
const PORT = Number(process.env.PORT || 4000);
const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET || JWT_SECRET.length < 32) {
  console.error("Set JWT_SECRET in .env (at least 32 characters).");
  process.exit(1);
}

app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin: process.env.FRONTEND_ORIGIN || `http://localhost:${PORT}` }));
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "..", "public")));
app.use("/api/auth", rateLimit({ windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false }));

const fail = (res, status, message) => res.status(status).json({ error: message });
const clean = v => typeof v === "string" ? v.trim() : "";
const validEmail = v => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
const tokenFor = user => jwt.sign({ id: user.id, role: user.role }, JWT_SECRET, { expiresIn: "12h", issuer: "abhipri-enterprises" });

function auth(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : "";
  if (!token) return fail(res, 401, "Please sign in.");
  try {
    const payload = jwt.verify(token, JWT_SECRET, { issuer: "abhipri-enterprises" });
    const user = db.prepare("SELECT id,name,email,phone,role,status FROM users WHERE id=?").get(payload.id);
    if (!user || user.status !== "active") return fail(res, 401, "Account unavailable.");
    req.user = user;
    next();
  } catch { return fail(res, 401, "Session expired. Please sign in again."); }
}
const allow = (...roles) => (req,res,next) => roles.includes(req.user.role) ? next() : fail(res,403,"You do not have permission for this action.");
const sellerBusiness = userId => db.prepare("SELECT * FROM businesses WHERE user_id=?").get(userId);

app.get("/api/health", (req,res) => res.json({ ok:true, service:"Abhipri Enterprises API", version:"0.2.0" }));

app.post("/api/auth/register", async (req,res) => {
  const name=clean(req.body.name), email=clean(req.body.email).toLowerCase(), phone=clean(req.body.phone);
  const password=String(req.body.password || ""), role=req.body.role;
  if (!name || !validEmail(email) || password.length < 8 || !["customer","seller"].includes(role))
    return fail(res,400,"Enter name, valid email, password (minimum 8 characters), and customer or seller account type.");
  if (role === "seller" && (!clean(req.body.businessName) || !clean(req.body.category) || !clean(req.body.state) || !clean(req.body.city)))
    return fail(res,400,"Seller registration requires business name, category, state and city.");
  try {
    const hash=await bcrypt.hash(password,12);
    const create=db.transaction(() => {
      const result=db.prepare("INSERT INTO users (name,email,phone,password_hash,role) VALUES (?,?,?,?,?)").run(name,email,phone,hash,role);
      if (role === "seller") db.prepare(`INSERT INTO businesses (user_id,business_name,category,description,state,city,address)
        VALUES (?,?,?,?,?,?,?)`).run(result.lastInsertRowid,clean(req.body.businessName),clean(req.body.category),clean(req.body.description),clean(req.body.state),clean(req.body.city),clean(req.body.address));
      return Number(result.lastInsertRowid);
    });
    const id=create();
    const user=db.prepare("SELECT id,name,email,phone,role,status FROM users WHERE id=?").get(id);
    res.status(201).json({ token:tokenFor(user), user, message: role==="seller" ? "Account created. Your business is pending admin approval." : "Account created." });
  } catch (e) {
    if (String(e.message).includes("UNIQUE")) return fail(res,409,"An account with this email already exists.");
    console.error(e); return fail(res,500,"Could not create account.");
  }
});

app.post("/api/auth/login", async (req,res) => {
  const email=clean(req.body.email).toLowerCase(), password=String(req.body.password || "");
  const user=db.prepare("SELECT * FROM users WHERE email=?").get(email);
  if (!user || !(await bcrypt.compare(password,user.password_hash))) return fail(res,401,"Email or password is incorrect.");
  if (user.status !== "active") return fail(res,403,"This account is suspended. Contact support.");
  const safe={id:user.id,name:user.name,email:user.email,phone:user.phone,role:user.role,status:user.status};
  res.json({ token:tokenFor(safe), user:safe });
});
app.get("/api/me",auth,(req,res)=>res.json({user:req.user}));

// Public business and approved-product discovery
app.get("/api/businesses",(req,res)=>{
  const q=`%${clean(req.query.q)}%`, state=clean(req.query.state), city=clean(req.query.city), category=clean(req.query.category);
  const rows=db.prepare(`SELECT b.id,b.business_name,b.category,b.description,b.state,b.city,b.created_at
    FROM businesses b JOIN users u ON u.id=b.user_id
    WHERE b.status='approved' AND u.status='active'
    AND (?='' OR b.business_name LIKE ? OR b.description LIKE ? OR b.category LIKE ?)
    AND (?='' OR b.state=?) AND (?='' OR b.city=?) AND (?='' OR b.category=?)
    ORDER BY b.business_name LIMIT 100`)
    .all(clean(req.query.q),q,q,q,state,state,city,city,category,category);
  res.json({items:rows});
});
app.get("/api/products",(req,res)=>{
  const q=`%${clean(req.query.q)}%`, category=clean(req.query.category);
  const rows=db.prepare(`SELECT p.id,p.name,p.description,p.category,p.price_paise,p.stock,b.business_name,b.city,b.state
    FROM products p JOIN businesses b ON b.id=p.business_id JOIN users u ON u.id=p.seller_id
    WHERE p.status='approved' AND b.status='approved' AND u.status='active' AND p.stock>0
    AND (?='' OR p.name LIKE ? OR p.description LIKE ? OR p.category LIKE ?)
    AND (?='' OR p.category=?) ORDER BY p.created_at DESC LIMIT 100`)
    .all(clean(req.query.q),q,q,q,category,category);
  res.json({items:rows});
});

// Seller workspace
app.get("/api/seller/business",auth,allow("seller"),(req,res)=>{
  const business=sellerBusiness(req.user.id);
  if(!business) return fail(res,404,"Business profile not found.");
  res.json({business});
});
app.post("/api/seller/products",auth,allow("seller"),(req,res)=>{
  const b=sellerBusiness(req.user.id);
  if(!b || b.status!=="approved") return fail(res,403,"Your business must be approved before publishing products.");
  const name=clean(req.body.name), category=clean(req.body.category), price=Number(req.body.price), stock=Number(req.body.stock);
  if(!name || !category || !Number.isFinite(price) || price<0 || !Number.isInteger(stock) || stock<0) return fail(res,400,"Enter a product name, category, valid price and whole-number stock.");
  const result=db.prepare("INSERT INTO products (seller_id,business_id,name,description,category,price_paise,stock) VALUES (?,?,?,?,?,?,?)")
    .run(req.user.id,b.id,name,clean(req.body.description),category,Math.round(price*100),stock);
  res.status(201).json({id:Number(result.lastInsertRowid),message:"Product submitted for admin approval."});
});
app.get("/api/seller/products",auth,allow("seller"),(req,res)=>{
  res.json({items:db.prepare("SELECT id,name,category,price_paise,stock,status,created_at FROM products WHERE seller_id=? ORDER BY id DESC").all(req.user.id)});
});
app.patch("/api/seller/products/:id",auth,allow("seller"),(req,res)=>{
  const p=db.prepare("SELECT * FROM products WHERE id=? AND seller_id=?").get(Number(req.params.id),req.user.id);
  if(!p) return fail(res,404,"Product not found.");
  const name=clean(req.body.name ?? p.name), category=clean(req.body.category ?? p.category);
  const price=req.body.price===undefined?p.price_paise/100:Number(req.body.price), stock=req.body.stock===undefined?p.stock:Number(req.body.stock);
  if(!name||!category||!Number.isFinite(price)||price<0||!Number.isInteger(stock)||stock<0) return fail(res,400,"Invalid product details.");
  db.prepare("UPDATE products SET name=?,description=?,category=?,price_paise=?,stock=?,status='pending' WHERE id=?")
    .run(name,clean(req.body.description ?? p.description),category,Math.round(price*100),stock,p.id);
  res.json({message:"Product updated and returned to pending review."});
});

// Customer orders; payment is intentionally pending until a real gateway is integrated.
app.post("/api/orders",auth,allow("customer"),(req,res)=>{
  const items=Array.isArray(req.body.items)?req.body.items:[];
  const s=req.body.shipping||{};
  if(!items.length || items.length>30) return fail(res,400,"Add between 1 and 30 order items.");
  const fields=["name","phone","address","city","state","pincode"];
  if(fields.some(k=>!clean(s[k]))) return fail(res,400,"Complete all shipping details.");
  try {
    const create=db.transaction(()=>{
      let total=0; const resolved=[];
      for(const item of items){
        const id=Number(item.productId), qty=Number(item.quantity);
        if(!Number.isInteger(id)||!Number.isInteger(qty)||qty<1||qty>100) throw new Error("Invalid product or quantity.");
        const p=db.prepare(`SELECT p.*,b.status business_status FROM products p JOIN businesses b ON b.id=p.business_id
          WHERE p.id=? AND p.status='approved' AND b.status='approved'`).get(id);
        if(!p || p.stock<qty) throw new Error("A product is unavailable or has insufficient stock.");
        total += p.price_paise*qty; resolved.push({p,qty});
      }
      const order=db.prepare(`INSERT INTO orders (customer_id,total_paise,shipping_name,shipping_phone,shipping_address,shipping_city,shipping_state,shipping_pincode)
        VALUES (?,?,?,?,?,?,?,?)`).run(req.user.id,total,clean(s.name),clean(s.phone),clean(s.address),clean(s.city),clean(s.state),clean(s.pincode));
      const add=db.prepare("INSERT INTO order_items (order_id,product_id,seller_id,product_name,quantity,unit_price_paise) VALUES (?,?,?,?,?,?)");
      const dec=db.prepare("UPDATE products SET stock=stock-? WHERE id=?");
      resolved.forEach(({p,qty})=>{add.run(order.lastInsertRowid,p.id,p.seller_id,p.name,qty,p.price_paise);dec.run(qty,p.id);});
      return Number(order.lastInsertRowid);
    });
    const id=create(); res.status(201).json({orderId:id,message:"Order placed. Payment is pending; no payment has been collected."});
  } catch(e){return fail(res,400,e.message);}
});
app.get("/api/orders/my",auth,allow("customer"),(req,res)=>{
  const orders=db.prepare("SELECT * FROM orders WHERE customer_id=? ORDER BY id DESC").all(req.user.id);
  const getItems=db.prepare("SELECT product_name,quantity,unit_price_paise FROM order_items WHERE order_id=?");
  res.json({items:orders.map(o=>({...o,items:getItems.all(o.id)}))});
});

// Admin operations
app.get("/api/admin/summary",auth,allow("admin"),(req,res)=>{
  const count=(table,where="")=>db.prepare(`SELECT COUNT(*) n FROM ${table} ${where}`).get().n;
  const revenue=db.prepare("SELECT COALESCE(SUM(total_paise),0) n FROM orders WHERE payment_status='paid'").get().n;
  res.json({customers:count("users","WHERE role='customer'"),sellers:count("users","WHERE role='seller'"),pendingBusinesses:count("businesses","WHERE status='pending'"),approvedBusinesses:count("businesses","WHERE status='approved'"),pendingProducts:count("products","WHERE status='pending'"),orders:count("orders"),paidRevenuePaise:revenue});
});
app.get("/api/admin/businesses",auth,allow("admin"),(req,res)=>{
  const status=clean(req.query.status);
  const rows=db.prepare(`SELECT b.*,u.name owner_name,u.email owner_email,u.phone owner_phone FROM businesses b JOIN users u ON u.id=b.user_id
    WHERE (?='' OR b.status=?) ORDER BY b.created_at DESC LIMIT 250`).all(status,status);
  res.json({items:rows});
});
app.patch("/api/admin/businesses/:id/status",auth,allow("admin"),(req,res)=>{
  const status=req.body.status;
  if(!["approved","rejected","suspended","pending"].includes(status)) return fail(res,400,"Invalid business status.");
  const r=db.prepare("UPDATE businesses SET status=? WHERE id=?").run(status,Number(req.params.id));
  if(!r.changes) return fail(res,404,"Business not found.");
  res.json({message:`Business status changed to ${status}.`});
});
app.get("/api/admin/products",auth,allow("admin"),(req,res)=>{
  const status=clean(req.query.status);
  res.json({items:db.prepare(`SELECT p.*,b.business_name,u.email seller_email FROM products p JOIN businesses b ON b.id=p.business_id JOIN users u ON u.id=p.seller_id
    WHERE (?='' OR p.status=?) ORDER BY p.created_at DESC LIMIT 300`).all(status,status)});
});
app.patch("/api/admin/products/:id/status",auth,allow("admin"),(req,res)=>{
  const status=req.body.status;
  if(!["approved","rejected","inactive","pending"].includes(status)) return fail(res,400,"Invalid product status.");
  const r=db.prepare("UPDATE products SET status=? WHERE id=?").run(status,Number(req.params.id));
  if(!r.changes) return fail(res,404,"Product not found.");
  res.json({message:`Product status changed to ${status}.`});
});
app.get("/api/admin/orders",auth,allow("admin"),(req,res)=>{
  res.json({items:db.prepare(`SELECT o.*,u.name customer_name,u.email customer_email FROM orders o JOIN users u ON u.id=o.customer_id ORDER BY o.id DESC LIMIT 300`).all()});
});
app.patch("/api/admin/orders/:id/status",auth,allow("admin"),(req,res)=>{
  const status=req.body.status;
  if(!["placed","accepted","shipped","delivered","cancelled"].includes(status)) return fail(res,400,"Invalid order status.");
  const r=db.prepare("UPDATE orders SET status=? WHERE id=?").run(status,Number(req.params.id));
  if(!r.changes) return fail(res,404,"Order not found.");
  res.json({message:"Order status updated."});
});
app.get("/api/admin/users",auth,allow("admin"),(req,res)=>{
  res.json({items:db.prepare("SELECT id,name,email,phone,role,status,created_at FROM users ORDER BY id DESC LIMIT 500").all()});
});
app.patch("/api/admin/users/:id/status",auth,allow("admin"),(req,res)=>{
  const status=req.body.status;
  if(!["active","suspended"].includes(status)) return fail(res,400,"Invalid user status.");
  const r=db.prepare("UPDATE users SET status=? WHERE id=? AND role!='admin'").run(status,Number(req.params.id));
  if(!r.changes) return fail(res,404,"User not found or protected admin account.");
  res.json({message:"User status updated."});
});

app.use((req,res)=>res.status(404).json({error:"Route not found."}));
app.use((err,req,res,next)=>{console.error(err);res.status(500).json({error:"Unexpected server error."});});
app.listen(PORT,()=>console.log(`Abhipri API running at http://localhost:${PORT}`));
