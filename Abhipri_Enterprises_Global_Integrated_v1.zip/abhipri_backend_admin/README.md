# Abhipri Enterprises — Backend + Admin Panel Starter

India-focused, Marathi/English marketplace foundation with customer and seller registration, seller product submission, customer order API, and a role-protected admin dashboard.

## Requirements
- Node.js 20+
- npm
- A long random JWT secret

## Setup
1. Extract the ZIP and open this folder in a terminal.
2. Run `npm install`.
3. Copy `.env.example` to `.env`.
4. Set a unique `JWT_SECRET` (at least 32 characters), and change `ADMIN_PASSWORD`.
5. Run `npm run db:init` to create the database and first administrator.
6. Run `npm start`.
7. Open:
   - `http://localhost:4000/admin/` — Super Admin
   - `http://localhost:4000/seller/` — Seller workspace
   - `http://localhost:4000/api/health` — API health check

The SQLite database is created under `data/` on first run.

## Unified global website integration (v1)
- The public Abhipri homepage is now served from `/` by the same Express application as `/admin/`, `/seller/`, and `/api/*`.
- Public business search calls `/api/businesses`; the customer/seller registration form calls `/api/auth/register`.
- The frontend, seller workspace, admin dashboard and API therefore share one server process and one database file.
- Responsive CSS includes desktop, tablet and mobile breakpoints. Test on real Android and desktop browsers before launch.
- This is a connected development build, not a production deployment. Product catalogue, checkout, payment gateway, customer account/order UI, full translation coverage and production hosting remain follow-up work.

## Included API
- `POST /api/auth/register` — customer or seller registration
- `POST /api/auth/login`, `GET /api/me`
- `GET /api/businesses`, `GET /api/products`
- `GET /api/seller/business`, `GET/POST/PATCH /api/seller/products`
- `POST /api/orders`, `GET /api/orders/my`
- Admin: `GET /api/admin/summary`, `/businesses`, `/products`, `/orders`, `/users`
- Admin status updates via `PATCH /api/admin/businesses/:id/status`, `/products/:id/status`, `/orders/:id/status`, `/users/:id/status`

Use `Authorization: Bearer <token>` for protected endpoints.

## Important limitations / production work still required
This is a development starter, not a launched or audited production service.
- The provided first-phase website prototype is a separate frontend; this backend starter currently serves its own admin and seller pages. Connect the public website to these APIs in the next integration step.
- Customer/seller signup API is available, but public signup forms still need to be wired into the website UI.
- Seller business approval and product moderation are supported in Admin.
- Orders are stored with `payment_status=pending`; **no real payment is collected**. Integrate a payment provider only after merchant onboarding/KYC, webhook signature verification, reconciliation, refunds and testing.
- No shipping carrier integration, GST invoicing, tax calculation, commissions/payouts, email/SMS/OTP, file uploads, chat, returns, disputes or notifications yet.
- No production backup/restore, monitoring, audit log, automated tests, penetration test or deployment configuration yet.
- SQLite is suitable for local development/small prototypes. For production multi-vendor workloads, migrate to managed PostgreSQL and add database migrations.
- Before launch: configure HTTPS, secure secrets, strict CORS, CSRF strategy if cookie auth is adopted, request validation, stronger rate limits, privacy policy, terms, refund/returns policy, grievance contact, data retention and access controls.
- Do not use the sample admin password in a public deployment.

## Suggested next milestone
Integrate the original Abhipri public frontend with the authentication, product catalogue and seller onboarding APIs; then add the complete Marathi/English customer and seller account screens.
